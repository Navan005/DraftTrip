DraftTrip is a hotel booking mobile application. You can book from a varity of available hotels according to your budget.

Team:
Harpal Singh
Jaswinder Kaur
Sukhman Kaur
Avneet Kaur
