package com.example.drafttrip;


public class BriefActivity {

}
